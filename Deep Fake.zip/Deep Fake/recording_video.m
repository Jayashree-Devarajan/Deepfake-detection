w = webcam(2);
% w = 'http://192.168.1.101:8080/shot.jpg';
%  I  = imread(w);
for c = 1:20
    img = w.snapshot;

    imshow(img) % display the image
    f1=il_rgb2gray(double(img));
  [ysize,xsize]=size(f1);
  nptsmax=40;   
  kparam=0.04;  
  pointtype=1;  
  sxl2=4;       
  sxi2=2*sxl2;  
  [posinit,valinit]=STIP(f1,kparam,sxl2,sxi2,pointtype,nptsmax);
  Test_Feat(c,1:40)=valinit;
   figure();imshow(f1,[]), hold on
 axis off;
 showellipticfeatures(posinit,[1 1 0]);
 title('Feature Points','fontsize',12,'fontname','Times New Roman','color','Black')
 posinit=mean(posinit)
 if(posinit(1)<790)

msgbox('Alert');
 end

end